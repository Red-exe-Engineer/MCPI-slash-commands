# Created by Wallee#8314/Red-exe-Engineer

# Imports
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

# Set the user's position to the void, instant death
mc.player.setPos(0, -1024, 0)
