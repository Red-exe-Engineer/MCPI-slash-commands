# Created by Wallee/red-exe-Engineer

# Imports
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

# Post some relevent infomation
mc.postToChat("Minecraft Pi: Reborn... Extended... Custom Command Script...")
mc.postToChat("This might as well be a light novel...")
mc.postToChat("Link: https://www.github.com/")
